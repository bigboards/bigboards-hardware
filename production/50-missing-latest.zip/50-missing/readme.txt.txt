file		qty	color		thickness	comments
--------------- ------- --------------- --------------- ---------------------------------------
cube-side	6x	white		5mm
cube-side-back	2x	white		5mm
hex-side	1x	white		5mm
hex-inner-top	1x	transparent	4mm
hex-side	1x	transparant	4mm
hex-lock-plate	1x	metal		1mm
