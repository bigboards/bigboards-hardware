file		qty	color		thickness	comments
--------------- ------- --------------- --------------- ---------------------------------------
cpu-mount	6x	transparent	4mm
inner-bottom	1x	transparent	4mm
inner-top	1x	transparent	4mm
switch-mount	1x	transparent	4mm
outer-top	1x	white		5mm
side		3x	white		5mm
side-back	1x	white		5mm
side-lock	1x	white		5mm
lock-plate	1x	metal		1mm
