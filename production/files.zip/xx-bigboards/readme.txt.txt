file		qty	color		thickness	comments
--------------- ------- --------------- --------------- ---------------------------------------
bottom		2x	transparent	4mm
inner-top	2x	transparent	4mm
mount-node	6x	transparent	4mm
mount-switch	2x	transparent	4mm
outer-top	2x	white           5mm
side		6x	white		5mm
side-back	2x	white		5mm